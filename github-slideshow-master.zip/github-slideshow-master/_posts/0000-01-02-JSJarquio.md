---
layout: slide
title: "Welcome to our second slide!"
---
New text created according to the directions in Step 7.
Use the left arrow to go back!
